from django.apps import AppConfig


class DestroyConfig(AppConfig):
    name = 'destroy'
