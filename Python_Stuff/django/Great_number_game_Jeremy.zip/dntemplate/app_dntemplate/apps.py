from django.apps import AppConfig


class AppDntemplateConfig(AppConfig):
    name = 'app_dntemplate'
