from django.apps import AppConfig


class RandoNumConfig(AppConfig):
    name = 'rando_num'
