from django.apps import AppConfig


class Blog1Config(AppConfig):
    name = 'blog1'
