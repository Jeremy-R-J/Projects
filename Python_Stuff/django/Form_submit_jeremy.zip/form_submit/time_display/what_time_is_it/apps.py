from django.apps import AppConfig


class WhatTimeIsItConfig(AppConfig):
    name = 'what_time_is_it'
