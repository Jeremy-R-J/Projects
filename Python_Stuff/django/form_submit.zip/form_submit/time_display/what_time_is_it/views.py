from django.shortcuts import  render, HttpResponse, redirect

def index(request):
        return render(request, "index.html")

def create_user(request):
    # this is the route that processes the form
    name_from_form = request.POST['name']
    last_from_form = request.POST['last']
    email_from_form = request.POST['email']
    # textarea_from_form = request.POST['txt']
    return redirect(f"filler/<{name_from_form}>/<{last_from_form}>/<{email_from_form}>")


def filler(request, name, last, email,):
    # this is the success route
    context = {
        "name" : name,
        "last" : last,
        "email" : email,
        # "txt" : txt,
    }
    return render(request,"filler.html", context)