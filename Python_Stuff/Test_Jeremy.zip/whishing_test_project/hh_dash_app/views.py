from django.shortcuts import  render, HttpResponse, redirect, render_to_response
from .models import User
from .models import  Job
from django.contrib import messages
import bcrypt

def login_page(request):
    if 'user_id' in request.session:
        return redirect( "/hand_helper_dash")
    return render(request, "login_page.html")
def view_page(request):
    if 'user_id' in request.session:
        return redirect( "/hand_helper_dash")
    return render(request, "view_page.html")


def register_user(request):
    print ("!!!!!!!!!!!!!!!!!!!!!!!!")
    print(request.POST)
    errors = User.objects.register_validator(request.POST)
    if len(errors) > 0:
        for i, value in errors.items():
            messages.error(request, value)
        return redirect('/')
    else:
        print('work please')
        print(request.POST)
        pw_hash = bcrypt.hashpw(request.POST.get('password').encode(), bcrypt.gensalt()).decode()
        if request.method=="POST":
            new_user = User.objects.create(
                first_name = request.POST['first_name'],
                last_name = request.POST['last_name'],
                email = request.POST['email'],
                password = pw_hash,
                )
            request.session['user_id'] =new_user.id
            print("Bitchin2")
        return redirect( "/hand_helper_dash")

def login_user(request):
    print('$$$$$$$$$$$$$$$$$$$$$$$$$$')
    print(request.POST)
    errors = User.objects.login_validator(request.POST)
    if len(errors) > 0:
        for i, value in errors.items():
            messages.error(request, value)
        return redirect('/')
    user=User.objects.filter(email=request.POST['email'])
    if user:
        logged_user= user[0]
        if bcrypt.checkpw(request.POST["password"].encode(), logged_user.password.encode()):
            request.session['user_id'] = logged_user.id
            return redirect('/hand_helper_dash')
        else:
            messages.add_message(request, messages.INFO, 'Incorrect User no access for you, foo!')    
            return redirect("/")

def delete_session(request):
    del request.session['user_id']
    return redirect("/")   

def hand_helper_dash(request):
    if 'user_id' not in request.session:
        return redirect("/")
    context = {
        "log_id": User.objects.filter(id=request.session['user_id']).first()
    }
    return render(request, 'hand_helper_dash.html', context)
def create_job(request):
    # errors = Job.objects.basic_validator(request.POST)
    # if len(errors) > 0:
    #     for i, value in errors.items():
    #         messages.error(request, value)
    #     return redirect('/new_job')
    # else:
        new_job= Job.objects.create()
        new_job.job_name = request.POST['job_name']
        new_job.desc = request.POST['desc']
        new_job.location = request.POST['location']
        # messages.success(request, "Job update succsesful")
        print("dam2")
        # create_job=Job.objects.create(
        # title=request.POST["title"],
        # desc=request.POST["desc"],
        # location=request.POST["location"],
        # )
        return redirect (f"/view_page/{create_job.id}")
def new_job(request):
    context = {
        "log_id": User.objects.filter(id=request.session['user_id']).first()
    }
    return render(request, "new_job.html", context)
    