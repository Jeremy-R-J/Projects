from django.urls import path
from .import views


urlpatterns = [
    path('', views.login_page),
    path('register_user', views.register_user),
    path('login_user', views.login_user),
    path('hand_helper_dash', views.hand_helper_dash),
    path('delete_session', views.delete_session),
    path('new_job', views.new_job),
    # path('view_page', views.view_page),
    path('view_page/<int:id>', views.view_page),
    path('create_job', views.create_job),
    # path('view_page/<int:id>', views.view_page),
    
]