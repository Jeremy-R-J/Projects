from django.apps import AppConfig


class HhDashAppConfig(AppConfig):
    name = 'hh_dash_app'
